//
//  MembersModel.swift
//  Facebook_Clone_Jordan
//
//  Created by Gabriela Artzi on 2025-01-30.
//

import Foundation

struct Members {
    var name: String
    var profileImage: String
}
