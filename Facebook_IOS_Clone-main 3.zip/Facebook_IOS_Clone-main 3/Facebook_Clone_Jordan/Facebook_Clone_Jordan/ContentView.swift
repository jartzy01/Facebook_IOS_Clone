//
//  ContentView.swift
//  Facebook_Clone_Jordan
//
//  Created by english on 2025-01-30.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabScreen()
    }
}

struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            TabScreen()
        }
    }
