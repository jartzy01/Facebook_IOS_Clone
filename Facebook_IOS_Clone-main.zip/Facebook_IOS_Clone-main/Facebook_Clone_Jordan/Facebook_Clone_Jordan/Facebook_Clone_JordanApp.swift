//
//  Facebook_Clone_JordanApp.swift
//  Facebook_Clone_Jordan
//
//  Created by english on 2025-01-30.
//

import SwiftUI

@main
struct Facebook_Clone_JordanApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
